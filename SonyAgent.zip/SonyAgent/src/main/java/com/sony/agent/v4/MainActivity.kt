package com.sony.agent.v4

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnEnableService: Button
    private lateinit var chatManager: LiveStreamChatManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.tvStatus)
        btnEnableService = findViewById(R.id.btnEnableService)

        chatManager = LiveStreamChatManager()

        btnEnableService.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }

    private fun updateServiceStatus() {
        val isServiceRunning = SonyAccessibilityService.isRunning
        if (isServiceRunning) {
            statusText.text = "Sony 4.0 Agent Status: ACTIVE"
            statusText.setTextColor(getColor(android.R.color.holo_green_dark))
            chatManager.connectLiveStream("sony_stream_channel_4")
        } else {
            statusText.text = "Sony 4.0 Agent Status: DISABLED"
            statusText.setTextColor(getColor(android.R.color.holo_red_dark))
        }
    }
}